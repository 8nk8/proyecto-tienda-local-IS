# Sistema de Pedidos en Línea para Tienda Local

Implementación funcional simplificada del proyecto de Ingeniería de Software.
Corresponde a la **Entrega 3: Producto Final** — código fuente del sistema
(Jacobson, Cap. 10).

## Stack

- **Python 3.9+** con **Flask** (servidor web)
- **SQLite** (base de datos, archivo único)
- **Jinja2** (plantillas HTML)
- **Werkzeug** (hashing de contraseñas)

## Instalación

```bash
# 1. Clonar o descomprimir el proyecto
cd tienda_local

# 2. (Recomendado) crear un entorno virtual
python -m venv venv
source venv/bin/activate          # En Windows: venv\Scripts\activate

# 3. Instalar dependencias
pip install -r requirements.txt

# 4. Correr la aplicación
python app.py
```

La primera vez que se ejecuta, se crea automáticamente la base de datos
`database/tienda.db` con datos de prueba.

Luego abrir en el navegador: <http://localhost:5000>

## Usuarios de prueba

| Rol         | Email                 | Contraseña     |
|-------------|-----------------------|----------------|
| Cliente     | cliente@tienda.com    | cliente123     |
| Encargado   | encargado@tienda.com  | encargado123   |

## Casos de uso implementados

| ID    | Caso de uso                       | Ruta                     |
|-------|-----------------------------------|--------------------------|
| CU-01 | Ver catálogo                      | `/`                      |
| CU-02 | Agregar producto al carrito       | `POST /carrito/agregar`  |
| CU-03 | Quitar producto del carrito       | `POST /carrito/quitar`   |
| CU-04 | Realizar pedido                   | `/checkout`              |
| CU-05 | Consultar pedidos del día (admin) | `/admin`                 |

## Estructura del proyecto

```
tienda_local/
├── app.py                # Punto de entrada Flask
├── config.py             # Configuración
├── requirements.txt
├── database/
│   ├── schema.sql        # DDL de las tablas
│   ├── seed.py           # Datos de prueba
│   └── db.py             # Helper de conexión
├── models/               # Clases de diseño (Jacobson 10.5.4)
│   ├── usuario.py
│   ├── producto.py
│   ├── carrito.py
│   └── pedido.py
├── routes/               # Controladores HTTP
│   ├── auth.py
│   ├── catalogo.py
│   ├── carrito.py
│   ├── pedidos.py
│   └── admin.py
├── templates/            # Plantillas Jinja2 (corresponden a los mockups)
├── static/style.css
└── tests/                # Reservado para Entrega 3 (Sommerville Cap. 8)
```

## Simplificaciones respecto al diseño original

Las siguientes decisiones se tomaron para mantener el código simple
sin perder trazabilidad con el modelo de análisis y diseño:

1. **`Cliente` y `Encargado` unificados** en una sola tabla `Usuario` con
   campo `rol`. Justificación: ambas clases compartían casi todos los
   atributos y se diferenciaban solo en el comportamiento, que se controla
   por el rol.
2. **`Dirección` se almacena como texto** dentro de `Pedido`, no como tabla
   separada. Justificación: en esta versión cada cliente escribe su
   dirección al confirmar el pedido (RF-05), sin gestión de múltiples
   direcciones persistentes.
3. **Pago sin pasarela real.** El sistema acepta `tarjeta` o `efectivo`
   pero no integra Stripe, PayPal, etc. El pedido se marca como
   `pendiente` en ambos casos.

## Para resetear la base de datos

```bash
rm database/tienda.db
python app.py
```
